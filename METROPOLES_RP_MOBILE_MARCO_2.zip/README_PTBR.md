# METROPOLES RP MOBILE — marco 2 (protótipo)

Este pacote amplia a base inicial com:
- bairro de teste gerado por blocos, ruas, calçadas e prédios com colisão;
- personagem em terceira pessoa;
- veículo de teste dirigível;
- HUD com botões básicos de toque e alternância personagem/veículo;
- controles de teclado para teste no editor.

**Ainda não é um jogo comercial completo nem um APK final.** Não inclui mapa GTA/FiveM,
ativos proprietários, multiplayer online, contas, banco de dados, economia persistente
ou limite validado de 256 jogadores.

## Abrir no Godot
1. Extraia o ZIP.
2. Abra Godot 4.3 ou superior.
3. Importe `project.godot` e pressione Play.

## Controles no editor
- Personagem: WASD/setas; mouse para câmera.
- Entre/sair do carro: tecla E.
- Carro: W/S acelera/freia, A/D vira.
- ESC libera o mouse.

## Controles touch
Na tela há setas de movimento, acelerador, freio e botão Entrar/Sair.
O protótipo usa botões simples; ainda não tem joystick analógico.

## Exportar para Android
É necessário configurar JDK, Android SDK e templates de exportação do Godot.
Depois crie um preset Android e gere APK/AAB. Teste em aparelhos reais:
a compatibilidade com “todos os Androids” não pode ser garantida sem testes.

## Próximas entregas
1. Mapa original detalhado com bairros e interiores.
2. Modelos 3D próprios de personagens e veículos.
3. Missões, inventário, identidade e sistemas de emprego.
4. Backend multiplayer dedicado, persistência e segurança.
5. Teste de carga antes de qualquer promessa de 256 jogadores por servidor.
