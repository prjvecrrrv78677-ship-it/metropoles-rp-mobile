extends CharacterBody3D

@export var move_speed := 5.5
@export var gravity := 18.0
@export var mouse_sensitivity := 0.004
@onready var pivot: Node3D = $CameraPivot
var touch_direction := Vector2.ZERO

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        pivot.rotate_y(-event.relative.x * mouse_sensitivity)
        pivot.rotation.x = clamp(pivot.rotation.x - event.relative.y * mouse_sensitivity, -0.65, 0.4)
    if event is InputEventKey and event.keycode == KEY_ESCAPE and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(delta: float) -> void:
    var keyboard := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    var input_dir := (keyboard + touch_direction).limit_length(1.0)
    var forward := -pivot.global_transform.basis.z
    var right := pivot.global_transform.basis.x
    var direction := right * input_dir.x + forward * -input_dir.y
    direction.y = 0
    direction = direction.normalized()
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()
    if direction.length() > 0.1:
        rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), delta * 8.0)

func set_touch_direction(value: Vector2) -> void:
    touch_direction = value
    await get_tree().create_timer(0.18).timeout
    touch_direction = Vector2.ZERO
