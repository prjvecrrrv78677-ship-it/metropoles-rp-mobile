extends Node3D

var player: CharacterBody3D
var car: CharacterBody3D
var driving := false
var hud: CanvasLayer

func _ready() -> void:
    _build_city()
    player = preload("res://scenes/player.tscn").instantiate()
    add_child(player)
    player.position = Vector3(-2, 1.1, 8)

    car = preload("res://scenes/car.tscn").instantiate()
    add_child(car)
    car.position = Vector3(3, 0.6, 8)

    _build_hud()

func _build_city() -> void:
    _box("Ground", Vector3(0, -0.3, 0), Vector3(150, 0.5, 150), Color(0.20, 0.38, 0.22), true)
    _box("MainRoad", Vector3(0, 0.01, 0), Vector3(150, 0.12, 13), Color(0.10, 0.11, 0.13), false)
    _box("CrossRoad", Vector3(0, 0.02, -30), Vector3(13, 0.13, 150), Color(0.10, 0.11, 0.13), false)
    for side in [-1, 1]:
        _box("Sidewalk", Vector3(0, 0.12, side * 8), Vector3(150, 0.25, 2), Color(0.55, 0.55, 0.52), true)
        _box("CrossSidewalk", Vector3(side * 8, 0.12, -30), Vector3(2, 0.25, 150), Color(0.55, 0.55, 0.52), true)

    var positions = [
        Vector3(-23, 0, -20), Vector3(23, 0, -20),
        Vector3(-23, 0, 22), Vector3(23, 0, 22),
        Vector3(-43, 0, -42), Vector3(43, 0, -42),
        Vector3(-43, 0, 42), Vector3(43, 0, 42)
    ]
    for i in range(positions.size()):
        var p: Vector3 = positions[i]
        var h := 9.0 + float((i * 7) % 13)
        var color := Color(0.42 + float(i % 3) * 0.08, 0.43, 0.47)
        _box("Building_%02d" % i, p + Vector3(0, h / 2.0, 0), Vector3(12, h, 12), color, true)
        # Fachada frontal simples para dar leitura visual ao quarteirão.
        _box("Facade_%02d" % i, p + Vector3(0, 1.8, 6.08), Vector3(5, 2.4, 0.12), Color(0.18, 0.25, 0.31), false)

    # Faixas centrais da avenida
    for x in range(-65, 70, 12):
        _box("LaneMark", Vector3(x, 0.09, 0), Vector3(5, 0.025, 0.22), Color(0.9, 0.82, 0.45), false)

func _box(label: String, pos: Vector3, size: Vector3, color: Color, solid: bool) -> void:
    var body := StaticBody3D.new() if solid else Node3D.new()
    body.name = label
    body.position = pos
    add_child(body)
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    mesh_instance.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh_instance.material_override = mat
    body.add_child(mesh_instance)
    if solid:
        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        collision.shape = shape
        body.add_child(collision)

func _build_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 510)
    panel.size = Vector2(280, 185)
    hud.add_child(panel)
    var column := VBoxContainer.new()
    panel.add_child(column)
    var title := Label.new()
    title.text = "METROPOLES RP • TESTE"
    column.add_child(title)
    var hint := Label.new()
    hint.text = "WASD / setas • E entra/sai"
    column.add_child(hint)
    _add_button(column, "↑ Frente", func(): _send_move(Vector2.UP))
    var row := HBoxContainer.new()
    column.add_child(row)
    _add_button(row, "←", func(): _send_move(Vector2.LEFT))
    _add_button(row, "↓", func(): _send_move(Vector2.DOWN))
    _add_button(row, "→", func(): _send_move(Vector2.RIGHT))
    _add_button(column, "ACELERAR", func(): _send_drive(1.0))
    _add_button(column, "FREAR", func(): _send_drive(-1.0))
    _add_button(column, "ENTRAR / SAIR (E)", _toggle_vehicle)

func _add_button(parent: Node, caption: String, action: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(100, 36)
    button.pressed.connect(action)
    parent.add_child(button)

func _send_move(direction: Vector2) -> void:
    if not driving and is_instance_valid(player):
        player.set_touch_direction(direction)

func _send_drive(amount: float) -> void:
    if driving and is_instance_valid(car):
        car.set_touch_throttle(amount)

func _toggle_vehicle() -> void:
    if not driving:
        if player.global_position.distance_to(car.global_position) < 5.0:
            driving = true
            player.visible = false
            player.set_physics_process(false)
            car.set_physics_process(true)
            car.get_node("Camera3D").current = true
    else:
        driving = false
        player.global_position = car.global_position + car.global_transform.basis.x * 2.0
        player.visible = true
        player.set_physics_process(true)
        car.set_physics_process(false)
        player.get_node("CameraPivot/SpringArm3D/Camera3D").current = true
