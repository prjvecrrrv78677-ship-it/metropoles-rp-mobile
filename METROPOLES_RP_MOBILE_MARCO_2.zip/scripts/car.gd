extends CharacterBody3D

@export var acceleration := 14.0
@export var max_speed := 22.0
@export var turn_speed := 1.8
@export var friction := 8.0
var touch_throttle := 0.0
var speed := 0.0

func _ready() -> void:
    set_physics_process(false)

func _physics_process(delta: float) -> void:
    var throttle := Input.get_action_strength("ui_up") - Input.get_action_strength("ui_down")
    throttle += touch_throttle
    throttle = clamp(throttle, -1.0, 1.0)
    speed = move_toward(speed, throttle * max_speed, acceleration * delta)
    if abs(throttle) < 0.05:
        speed = move_toward(speed, 0.0, friction * delta)
    var steering := Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
    rotation.y -= steering * turn_speed * delta * sign(speed)
    var forward := -global_transform.basis.z
    velocity.x = forward.x * speed
    velocity.z = forward.z * speed
    velocity.y -= 18.0 * delta
    move_and_slide()

func set_touch_throttle(value: float) -> void:
    touch_throttle = value
    await get_tree().create_timer(0.2).timeout
    touch_throttle = 0.0
