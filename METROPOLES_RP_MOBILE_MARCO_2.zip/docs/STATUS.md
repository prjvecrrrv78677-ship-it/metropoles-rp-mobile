# Estado honesto do projeto

Implementado neste marco:
- cena 3D de teste;
- quarteirões e avenida provisórios;
- colisões básicas;
- personagem e câmera em terceira pessoa;
- veículo de teste com aceleração e direção;
- HUD com botões de toque e entrar/sair do veículo.

Não implementado:
- arte final ou mapa de escala GTA V/FiveM;
- multiplayer, contas, matchmaking ou servidores;
- 256 jogadores simultâneos;
- inventário, empregos, polícia, hospital, casas ou economia;
- APK assinado e testado em dispositivos.

Este pacote é uma etapa de desenvolvimento, não o produto final.
